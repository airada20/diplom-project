const likes = document.querySelectorAll('.like');

likes.forEach(like => {
  const plus = like.querySelector('.plus');
  const counter_element = like.querySelector('.counter');

  let counter = 0;
  
  plus.addEventListener('click', () => {
    render(++counter, counter_element);
  });

  localStorage.setItem("likes", counter.toString());
});

const render = (counter, counter_element) => counter_element.innerText = counter;

